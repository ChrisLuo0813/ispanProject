package tw.com.ispan.eeit48.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tw.com.ispan.eeit48.dao.membersRepository;
import tw.com.ispan.eeit48.model.members;

//跨域需求要加這個Annoation
@CrossOrigin
@RestController
@RequestMapping

public class membersController {
	@Autowired
	membersRepository membersRepository;
	@Autowired
	members member,member1,member2;
	@Autowired
	HttpSession localSession;
	
	Date date = new Date();
	SimpleDateFormat dd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	    @CrossOrigin
	    @PostMapping(path = {"/doRegister"})
	//只要在接受方法上宣告HttpSession session好像就能直接使用
	    public String SaveAndCheckAccount( members createMember,HttpSession session) {
	//account password email要和前端AJAX傳來的KEY名稱一致    
	    	System.out.println(createMember.getMember_account() +':'+createMember.getMember_password());
	//驗證帳號是否重複 重複會SYSOUT account exist    
	    	if(membersRepository.queryBymember_account(createMember.getMember_account())!=null) {
	            System.out.println("account exist");
	            return "此帳號已被使用";
	    }else{      
//	    			SimpleDateFormat dd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    			member.setMember_account(createMember.getMember_account());
	    	        member.setMember_email(createMember.getMember_email());
	    	        member.setMember_password(createMember.getMember_password());
	    	        member.setAccount_create_time(dd.format(date));
	    	        member.setLast_login_time(dd.format(date));
	    	        membersRepository.saveAndFlush(member);
	    	        System.out.println("insertOK");
	    	        return "帳號創立成功！請重新登入";
	    	    }
//	    	return "index";	
	    }
	    
	    @CrossOrigin
	    @PostMapping(path = {"/loginRegister"})
	    public String LoginAndCheckAccount( members loginMember,HttpSession session) {
	    	
	//account password email要和前端AJAX傳來的KEY名稱一致    
	    	System.out.println(loginMember.getMember_account() +':'+loginMember.getMember_password());
	//驗證帳號密碼是否正確    
	    	member = membersRepository.queryBymember_password(loginMember.getMember_account(),
					loginMember.getMember_password());
	    	if(member == null) {
	            System.out.println("帳號或密碼輸入錯誤");
	            return "帳號或密碼輸入錯誤";
	    }else{   
			System.out.println("Login OK");
			member.setLast_login_time(dd.format(date));
			membersRepository.saveAndFlush(member);
			localSession = session;
			localSession.setAttribute("member", member);
			return "歡迎回來" + member.getMember_nickname();
	    	    }
	    }
	    
	    @CrossOrigin
	    @GetMapping(path = {"/getRegister"})
	    public members getAccount() {
//	    	System.out.println("GG");
	    	member2 = (members) localSession.getAttribute("member");
	    return  member2;
	    
	    }
	    
}