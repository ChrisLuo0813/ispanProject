package tw.com.ispan.eeit48;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabwebBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabwebBootApplication.class, args);
	}

}
