package tw.com.ispan.eeit48.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tw.com.ispan.eeit48.dao.membersRepository;
import tw.com.ispan.eeit48.model.members;

//跨域需求要加這個Annoation
@CrossOrigin
@RestController
@RequestMapping

public class membersController {
	@Autowired
	membersRepository membersRepository;
	@Autowired
	members member,member1,member2;
	@Autowired
	HttpSession localSession;
	
	BCryptPasswordEncoder bcpe = new BCryptPasswordEncoder() ;
	Date date = new Date();
	SimpleDateFormat dd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	    @CrossOrigin
	    @PostMapping(path = {"/doRegister"})
	    public String SaveAndCheckAccount(members createMember) {
	//account password email要和前端AJAX傳來的KEY名稱一致    
	//驗證帳號是否重複 重複會SYSOUT account exist    
	    	if(membersRepository.queryBymember_account(createMember.getMember_account())!=null) {
	            System.out.println("account exist");
	            return "此帳號已被使用";
	    }else{      
//	    			SimpleDateFormat dd = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    			member.setMember_account(createMember.getMember_account());
	    	        member.setMember_email(createMember.getMember_email());
	    	        //將user輸入的密碼進行加密
	    	        member.setMember_password(bcpe.encode(createMember.getMember_password()));
	    	        //寫入創帳號日期
	    	        member.setAccount_create_time(dd.format(date));
//	    	        member.setLast_login_time(dd.format(date));
	    	        membersRepository.saveAndFlush(member);
	    	        System.out.println("insertOK");
	    	        return "帳號創立成功！請重新登入";
	    	    }
	    }
	    
	    @CrossOrigin
	    @PostMapping(path = {"/loginRegister"})
	    public String LoginAndCheckAccount( members loginMember,HttpSession session) {
	    	//在接受方法上宣告HttpSession session，並將這個session存到localSession裡面，後面都用localSession呼叫參數
	    	
	//account password要和前端AJAX傳來的KEY名稱一致    
	    	System.out.println(loginMember.getMember_account() +':'+loginMember.getMember_password());
	//驗證帳號密碼是否正確    
//	    	member = membersRepository.queryBymember_password(loginMember.getMember_account(),
//					loginMember.getMember_password());
	    	member = membersRepository.queryBymember_account(loginMember.getMember_account());
	    	if(member == null) {
	            System.out.println("帳號或密碼輸入錯誤");
	            return "帳號或密碼輸入錯誤";
	    }else{   
	    	Boolean	isright = bcpe.matches(loginMember.getMember_password(), member.getMember_password());
    		if(isright) {
			System.out.println("Login OK");
			member.setLast_login_time(dd.format(date));
			membersRepository.saveAndFlush(member);
			localSession = session;
			localSession.setAttribute("member", member);
			return "歡迎回來" + member.getMember_nickname();
					}
					System.out.println("帳號或密碼輸入錯誤");
			        return "帳號或密碼輸入錯誤";
	    	    }
	    	}
	    
	    @CrossOrigin
	    @GetMapping(path = {"/getRegister"})
	    public members GetAccount() {
//	    	System.out.println("GG");
	    	member2 = (members) localSession.getAttribute("member");
	    	String pw = member2.getMember_password();
	    	System.out.println(bcpe.encode(pw));
	    	System.out.println(pw); 
	    	System.out.println(bcpe.matches(pw, bcpe.encode(pw)));
	    	System.out.println(bcpe.matches(pw, pw) + "OK");
	    	if(member2==null) {
	    		return null;
	    	}
	    return  member2;
	    }
	    
	    @CrossOrigin
	    @GetMapping(path = {"/logoutRegister"})
	    public String LogoutAccount() {
	    	localSession.removeAttribute("member");
	    return  "帳號已登出";
	    
	    }
	    
	    @CrossOrigin
	    @PostMapping(path = {"/changeRegister"})
	    public String changeAccount(members changeMember) {
	    	membersRepository.saveAndFlush(changeMember);
	    	localSession.setAttribute("member", changeMember);
	    return  "帳號資料已更新";
	    
	    }
}