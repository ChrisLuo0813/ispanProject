package tw.com.ispan.eeit48.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import tw.com.ispan.eeit48.model.items;

@Repository
public interface itemsRepository extends JpaRepository<items, Integer>{
//	@Query(value = "",nativeQuery = true)
//	items queryByrated_item_id(Integer id);
}