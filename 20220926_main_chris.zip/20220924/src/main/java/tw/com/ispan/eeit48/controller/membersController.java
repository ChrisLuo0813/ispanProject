package tw.com.ispan.eeit48.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tw.com.ispan.eeit48.dao.membersRepository;
import tw.com.ispan.eeit48.model.members;

//跨域需求要加這個Annoation
@CrossOrigin
@RestController
public class membersController {
	@Autowired
	membersRepository membersRepository;
	@Autowired
	members member,member1;

	    @CrossOrigin
	    @RequestMapping(path = {"/doRegister"})
	//只要在接受方法上宣告HttpSession session好像就能直接使用
	    public String methodSaveAndCheckAccount(@RequestBody members createMember,HttpSession session) {
	//account password email要和前端AJAX傳來的KEY名稱一致    
	    	System.out.println(createMember.getMember_account() +':'+createMember.getMember_password());
	//驗證帳號是否重複 重複會SYSOUT account exist    
	    	if(membersRepository.queryBymember_account(createMember.getMember_account())!=null) {
	            System.out.println("account exist");
	            return "此帳號已被使用";
	    }else{        
	    			member.setMember_account(createMember.getMember_account());
	    	        member.setMember_email(createMember.getMember_email());
	    	        member.setMember_password(createMember.getMember_email());
	    	        membersRepository.saveAndFlush(member);
	    	        System.out.println("insertOK");
	    	            System.out.println(member.getMember_id());
	    	            session.setAttribute("member", member);
	    	           member1 = (members) session.getAttribute("member");
	    	           System.out.println(member1.getMember_id());
	    	        return "/index";
	    	    }
//	    	return "index";	
	    }
}