package tw.com.ispan.eeit48.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Entity

@Table(name = "item_states" ,schema ="PUBLIC")
public class item_states {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "item_state_id")
	private Integer item_state_id;
	
	@Column(name = "item_state")
	private String item_state;

	public Integer getItem_state_id() {
		return item_state_id;
	}

	public void setItem_state_id(Integer item_state_id) {
		this.item_state_id = item_state_id;
	}

	public String getItem_state() {
		return item_state;
	}

	public void setItem_state(String item_state) {
		this.item_state = item_state;
	}
	
	
	
	
}
